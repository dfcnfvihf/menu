## About
This game is an old project that I started in July 2019. I hope you enjoy it.
 * Make sure to share it with your friends :)

## Screenshots
![](https://raw.githubusercontent.com/Psi505/Batch-Pong-Game/main/image_1.png)

![](https://raw.githubusercontent.com/Psi505/Batch-Pong-Game/main/image_2.png)